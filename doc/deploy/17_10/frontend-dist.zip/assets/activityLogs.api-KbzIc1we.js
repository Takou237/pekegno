import{h as i}from"./index-BP8rHTGP.js";const o={async list(t={}){const{data:a}=await i.get("/activity-logs",{params:t});return a}};export{o as a};
