const e=["especes","orange_money","mobile_money"],a=["sale","renewal","upgrade","monthly_revenue","growth","manual"];export{e as C,a};
