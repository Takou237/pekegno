import{h as i}from"./index-De3ePFJM.js";const o={async list(t={}){const{data:a}=await i.get("/activity-logs",{params:t});return a}};export{o as a};
